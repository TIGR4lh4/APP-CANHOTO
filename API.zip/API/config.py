DB_CONFIG = {
    "host": "192.168.10.250",
    "port": 3306,
    "user": "root",
    "password": "h1p3rs0n1c0!@#$",
    "database": "gniweb"
}
SECRET_KEY = "7198e30a2bbc484147cc8cd00433ce1f"